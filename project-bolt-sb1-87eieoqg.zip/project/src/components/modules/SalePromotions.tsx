import React from 'react';
import { Calendar, Tag, Percent } from 'lucide-react';

export const SalePromotions = () => {
  const promotions = [
    {
      id: 1,
      title: "Summer Sale Special",
      discount: "15%",
      duration: "7 days",
      properties: 24,
      status: "active"
    },
    {
      id: 2,
      title: "Flash Deal Weekend",
      discount: "10%",
      duration: "3 days",
      properties: 15,
      status: "upcoming"
    },
    {
      id: 3,
      title: "Holiday Season Offer",
      discount: "20%",
      duration: "7 days",
      properties: 32,
      status: "draft"
    }
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Sale Promotions</h1>
        <button className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
          Create Promotion
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {promotions.map((promo) => (
          <div key={promo.id} className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg text-gray-800">{promo.title}</h3>
              <span className={`px-3 py-1 rounded-full text-sm ${
                promo.status === 'active' ? 'bg-green-100 text-green-800' :
                promo.status === 'upcoming' ? 'bg-blue-100 text-blue-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {promo.status}
              </span>
            </div>

            <div className="space-y-3">
              <div className="flex items-center text-gray-600">
                <Percent className="w-5 h-5 mr-2" />
                <span>Discount: {promo.discount}</span>
              </div>
              <div className="flex items-center text-gray-600">
                <Calendar className="w-5 h-5 mr-2" />
                <span>Duration: {promo.duration}</span>
              </div>
              <div className="flex items-center text-gray-600">
                <Tag className="w-5 h-5 mr-2" />
                <span>{promo.properties} Properties</span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-100 flex justify-end space-x-3">
              <button className="px-4 py-2 text-gray-600 hover:text-gray-800">
                Edit
              </button>
              <button className="px-4 py-2 text-primary-600 hover:text-primary-800">
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}