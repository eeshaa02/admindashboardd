import React from 'react';
import { Sofa, Tag, ShoppingCart, Heart } from 'lucide-react';

export const FurnitureListings = () => {
  const furniture = [
    {
      id: 1,
      name: "Modern Leather Sofa",
      category: "Living Room",
      price: "$1,299",
      stock: 5,
      image: "https://images.pexels.com/photos/1571471/pexels-photo-1571471.jpeg"
    },
    {
      id: 2,
      name: "Dining Table Set",
      category: "Dining Room",
      price: "$899",
      stock: 3,
      image: "https://images.pexels.com/photos/1571472/pexels-photo-1571472.jpeg"
    },
    {
      id: 3,
      name: "Queen Size Bed Frame",
      category: "Bedroom",
      price: "$799",
      stock: 8,
      image: "https://images.pexels.com/photos/1571470/pexels-photo-1571470.jpeg"
    }
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Furniture Listings</h1>
        <button className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
          Add Furniture
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {furniture.map((item) => (
          <div key={item.id} className="bg-white rounded-xl overflow-hidden shadow-sm">
            <div className="h-48 overflow-hidden relative group">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <button className="p-2 bg-white rounded-full mx-2 hover:bg-gray-100">
                  <Heart className="w-5 h-5 text-gray-600" />
                </button>
                <button className="p-2 bg-white rounded-full mx-2 hover:bg-gray-100">
                  <ShoppingCart className="w-5 h-5 text-gray-600" />
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold text-lg text-gray-800">{item.name}</h3>
                <span className="text-primary-600 font-semibold">{item.price}</span>
              </div>
              
              <div className="flex items-center text-gray-600 mb-4">
                <Tag className="w-4 h-4 mr-2" />
                <span>{item.category}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className={`text-sm ${
                  item.stock > 5 ? 'text-green-600' : 'text-orange-600'
                }`}>
                  {item.stock} in stock
                </span>
                <button className="px-4 py-2 bg-gray-50 text-gray-800 rounded-lg hover:bg-gray-100 transition-colors">
                  Edit Listing
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}