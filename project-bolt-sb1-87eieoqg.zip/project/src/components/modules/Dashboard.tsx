import React from 'react';
import { StatCard } from '../common/StatCard';
import { Building2, Users, DollarSign, TrendingUp } from 'lucide-react';

export const Dashboard = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Dashboard Overview</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Properties"
          value="2,543"
          icon={Building2}
          trend={{ value: 12.5, isPositive: true }}
        />
        <StatCard
          title="Active Listings"
          value="1,832"
          icon={TrendingUp}
          trend={{ value: 8.2, isPositive: true }}
        />
        <StatCard
          title="Total Revenue"
          value="$324,582"
          icon={DollarSign}
          trend={{ value: 15.3, isPositive: true }}
        />
        <StatCard
          title="New Clients"
          value="432"
          icon={Users}
          trend={{ value: 4.1, isPositive: false }}
        />
      </div>
    </div>
  );
}