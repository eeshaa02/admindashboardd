import React from 'react';
import { Building2, Users, Calendar, MapPin } from 'lucide-react';

export const DevelopmentProjects = () => {
  const projects = [
    {
      id: 1,
      name: "Sunset Valley Residences",
      location: "123 Sunset Boulevard",
      units: 48,
      completion: "2024 Q4",
      status: "in-progress",
      progress: 65
    },
    {
      id: 2,
      name: "Green Heights Complex",
      location: "456 Park Avenue",
      units: 96,
      completion: "2025 Q2",
      status: "planning",
      progress: 20
    },
    {
      id: 3,
      name: "Marina Bay Towers",
      location: "789 Waterfront Drive",
      units: 120,
      completion: "2025 Q1",
      status: "in-progress",
      progress: 35
    }
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Development Projects</h1>
        <button className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
          Add New Project
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {projects.map((project) => (
          <div key={project.id} className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-semibold text-lg text-gray-800">{project.name}</h3>
                <div className="flex items-center text-gray-600 mt-1">
                  <MapPin className="w-4 h-4 mr-1" />
                  <span className="text-sm">{project.location}</span>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm ${
                project.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                project.status === 'planning' ? 'bg-yellow-100 text-yellow-800' :
                'bg-green-100 text-green-800'
              }`}>
                {project.status}
              </span>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between text-gray-600">
                <div className="flex items-center">
                  <Building2 className="w-5 h-5 mr-2" />
                  <span>{project.units} Units</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  <span>{project.completion}</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm text-gray-600">Progress</span>
                  <span className="text-sm font-medium text-gray-800">{project.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-primary-600 h-2 rounded-full"
                    style={{ width: `${project.progress}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-100 flex justify-end space-x-3">
              <button className="px-4 py-2 text-gray-600 hover:text-gray-800">
                View Details
              </button>
              <button className="px-4 py-2 text-primary-600 hover:text-primary-800">
                Update Progress
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}