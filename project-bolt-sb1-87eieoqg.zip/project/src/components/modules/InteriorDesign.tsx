import React from 'react';
import { Paintbrush, Star, Clock, User } from 'lucide-react';

export const InteriorDesign = () => {
  const services = [
    {
      id: 1,
      title: "Modern Minimalist Design",
      designer: "Sarah Johnson",
      rating: 4.8,
      duration: "4-6 weeks",
      price: "$2,500",
      image: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg"
    },
    {
      id: 2,
      title: "Contemporary Luxury",
      designer: "Michael Chen",
      rating: 4.9,
      duration: "6-8 weeks",
      price: "$3,800",
      image: "https://images.pexels.com/photos/1571458/pexels-photo-1571458.jpeg"
    },
    {
      id: 3,
      title: "Scandinavian Style",
      designer: "Emma Wilson",
      rating: 4.7,
      duration: "3-5 weeks",
      price: "$2,200",
      image: "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg"
    }
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Interior Design Services</h1>
        <button className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
          Request Design
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((service) => (
          <div key={service.id} className="bg-white rounded-xl overflow-hidden shadow-sm">
            <div className="h-48 overflow-hidden">
              <img
                src={service.image}
                alt={service.title}
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="p-6">
              <h3 className="font-semibold text-lg text-gray-800 mb-2">{service.title}</h3>
              
              <div className="space-y-2">
                <div className="flex items-center text-gray-600">
                  <User className="w-4 h-4 mr-2" />
                  <span>{service.designer}</span>
                </div>
                
                <div className="flex items-center text-gray-600">
                  <Star className="w-4 h-4 mr-2 text-yellow-400" />
                  <span>{service.rating} Rating</span>
                </div>
                
                <div className="flex items-center text-gray-600">
                  <Clock className="w-4 h-4 mr-2" />
                  <span>{service.duration}</span>
                </div>
                
                <div className="text-lg font-semibold text-primary-600 mt-2">
                  {service.price}
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-100">
                <button className="w-full px-4 py-2 bg-gray-50 text-gray-800 rounded-lg hover:bg-gray-100 transition-colors">
                  View Details
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}