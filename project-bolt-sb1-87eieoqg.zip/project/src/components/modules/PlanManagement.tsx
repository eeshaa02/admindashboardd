import React from 'react';
import { Crown, Check, Star, MapPin, Users, Clock, Shield } from 'lucide-react';
import { PlanBadge } from '../common/PlanBadge';

export const PlanManagement = () => {
  const plans = [
    {
      type: "Basic",
      price: "Free",
      description: "Perfect for getting started with property listings",
      features: [
        "Free property listing",
        "Basic visibility in search results",
        "Direct customer inquiries",
        "Standard customer support",
        "Basic analytics dashboard",
        "Email notifications"
      ]
    },
    {
      type: "Premium",
      price: "$49",
      description: "Advanced features for professional real estate agents",
      features: [
        "Premium listing placement",
        "Highlighted in search results",
        "Featured map marker",
        "Priority customer matching",
        "Premium customer support",
        "Geo-tagging of properties",
        "Geo-fencing support",
        "Survey scheduling",
        "Agent intervention for lead handling",
        "Geofence alerts and notifications"
      ]
    },
    {
      type: "Partnered",
      price: "$99",
      description: "Complete solution for real estate businesses",
      features: [
        "Professional property photoshoot",
        "Dedicated real estate agent",
        "Property inspection assistance",
        "End-to-end process coordination",
        "Premium customer support",
        "Guaranteed visibility",
        "Geo-tagging and geo-fencing",
        "GIS integration",
        "Real-time geofence alerts",
        "Priority support 24/7"
      ]
    }
  ];

  const getIcon = (feature: string) => {
    if (feature.includes('support')) return Shield;
    if (feature.includes('agent')) return Users;
    if (feature.includes('visibility')) return Star;
    if (feature.includes('geo')) return MapPin;
    if (feature.includes('scheduling')) return Clock;
    return Check;
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Plan Management</h1>
          <p className="text-gray-600 mt-2">Choose the perfect plan for your real estate business</p>
        </div>
        <button className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
          Customize Plans
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan) => (
          <div 
            key={plan.type} 
            className={`bg-white rounded-xl p-6 shadow-sm border-2 ${
              plan.type === "Premium" ? "border-primary-500" : "border-transparent"
            } relative`}
          >
            {plan.type === "Premium" && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-primary-500 text-white px-4 py-1 rounded-full text-sm">
                  Most Popular
                </span>
              </div>
            )}
            
            <div className="flex justify-between items-start mb-4">
              <PlanBadge type={plan.type as "Basic" | "Premium" | "Partnered"} />
              <Crown className={`w-6 h-6 ${
                plan.type === "Premium" ? "text-primary-600" :
                plan.type === "Partnered" ? "text-purple-600" :
                "text-gray-400"
              }`} />
            </div>

            <div className="mt-4">
              <div className="flex items-baseline">
                <span className="text-4xl font-bold text-gray-800">{plan.price}</span>
                {plan.type !== "Basic" && (
                  <span className="text-gray-500 ml-2">/month</span>
                )}
              </div>
              <p className="text-gray-600 mt-2">{plan.description}</p>
            </div>

            <div className="mt-6 space-y-4">
              {plan.features.map((feature, index) => {
                const Icon = getIcon(feature);
                return (
                  <div key={index} className="flex items-start">
                    <Icon className={`w-5 h-5 mr-3 flex-shrink-0 ${
                      plan.type === "Premium" ? "text-primary-500" :
                      plan.type === "Partnered" ? "text-purple-500" :
                      "text-green-500"
                    }`} />
                    <span className="text-gray-600">{feature}</span>
                  </div>
                );
              })}
            </div>

            <button className={`w-full mt-8 px-6 py-3 rounded-lg transition-colors font-medium ${
              plan.type === "Basic" ?
                "bg-gray-100 text-gray-800 hover:bg-gray-200" :
              plan.type === "Premium" ?
                "bg-primary-600 text-white hover:bg-primary-700" :
                "bg-purple-600 text-white hover:bg-purple-700"
            }`}>
              {plan.type === "Basic" ? "Get Started" : "Upgrade Plan"}
            </button>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-gray-50 rounded-xl p-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Need a Custom Plan?</h2>
        <p className="text-gray-600 mb-6">
          We offer tailored solutions for large real estate agencies and property developers.
          Contact our sales team to discuss your specific requirements.
        </p>
        <button className="px-6 py-3 bg-white text-gray-800 rounded-lg hover:bg-gray-100 transition-colors border border-gray-200">
          Contact Sales
        </button>
      </div>
    </div>
  );
}