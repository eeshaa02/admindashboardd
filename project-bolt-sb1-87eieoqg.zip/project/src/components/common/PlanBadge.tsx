import React from 'react';

interface PlanBadgeProps {
  type: 'Basic' | 'Premium' | 'Partnered';
}

export const PlanBadge: React.FC<PlanBadgeProps> = ({ type }) => {
  const styles = {
    Basic: 'bg-gray-100 text-gray-800',
    Premium: 'bg-primary-100 text-primary-800',
    Partnered: 'bg-purple-100 text-purple-800',
  };

  return (
    <span className={`px-3 py-1 rounded-full text-sm font-medium ${styles[type]}`}>
      {type}
    </span>
  );
}