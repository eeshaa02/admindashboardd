import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Building2,
  Paintbrush,
  Sofa,
  BadgeDollarSign,
  Settings,
  PlusSquare,
  Crown,
} from 'lucide-react';
import type { NavItem } from '../../types';

const navItems: NavItem[] = [
  { title: 'Dashboard', path: '/', icon: LayoutDashboard },
  { title: 'Post Ad', path: '/post-ad', icon: PlusSquare },
  { title: 'Sale Promotions', path: '/promotions', icon: BadgeDollarSign },
  { title: 'Development Projects', path: '/projects', icon: Building2 },
  { title: 'Interior Design', path: '/interior', icon: Paintbrush },
  { title: 'Furniture Listings', path: '/furniture', icon: Sofa },
  { title: 'Plan Management', path: '/plans', icon: Crown },
  { title: 'Settings', path: '/settings', icon: Settings },
];

export const Sidebar = () => {
  const location = useLocation();

  return (
    <aside className="w-64 bg-white h-screen fixed left-0 top-0 border-r border-gray-200">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-gray-800">RealAdmin</h1>
      </div>
      <nav className="mt-6">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center px-6 py-3 text-gray-700 hover:bg-gray-50 hover:text-primary-600 transition-colors ${
              location.pathname === item.path ? 'bg-primary-50 text-primary-600' : ''
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span className="ml-3">{item.title}</span>
          </Link>
        ))}
      </nav>
    </aside>
  );
}