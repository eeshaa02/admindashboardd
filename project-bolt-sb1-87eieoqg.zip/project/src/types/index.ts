export interface NavItem {
  title: string;
  path: string;
  icon: React.ComponentType;
}

export interface Plan {
  name: string;
  type: 'Basic' | 'Premium' | 'Partnered';
  features: string[];
}

export interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ComponentType;
  trend?: {
    value: number;
    isPositive: boolean;
  };
}