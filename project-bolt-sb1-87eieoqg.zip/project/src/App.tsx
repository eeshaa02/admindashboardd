import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AdminLayout } from './components/layout/AdminLayout';
import { Dashboard } from './components/modules/Dashboard';
import { PostAd } from './components/modules/PostAd';
import { SalePromotions } from './components/modules/SalePromotions';
import { DevelopmentProjects } from './components/modules/DevelopmentProjects';
import { InteriorDesign } from './components/modules/InteriorDesign';
import { FurnitureListings } from './components/modules/FurnitureListings';
import { PlanManagement } from './components/modules/PlanManagement';

const App: React.FC = () => {
  return (
    <Router>
      <AdminLayout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/post-ad" element={<PostAd />} />
          <Route path="/promotions" element={<SalePromotions />} />
          <Route path="/projects" element={<DevelopmentProjects />} />
          <Route path="/interior" element={<InteriorDesign />} />
          <Route path="/furniture" element={<FurnitureListings />} />
          <Route path="/plans" element={<PlanManagement />} />
        </Routes>
      </AdminLayout>
    </Router>
  );
};

export default App;